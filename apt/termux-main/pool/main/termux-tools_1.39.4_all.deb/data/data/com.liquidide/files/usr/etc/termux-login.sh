##
## This script is sourced by /data/data/com.liquidide/files/usr/bin/login before executing shell.
##
