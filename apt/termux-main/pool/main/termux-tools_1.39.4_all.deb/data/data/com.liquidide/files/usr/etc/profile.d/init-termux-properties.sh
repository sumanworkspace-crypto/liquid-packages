if [ ! -f /data/data/com.liquidide/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.liquidide/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.liquidide/files/home/.termux
	cp /data/data/com.liquidide/files/usr/share/examples/termux/termux.properties /data/data/com.liquidide/files/home/.termux/
fi
